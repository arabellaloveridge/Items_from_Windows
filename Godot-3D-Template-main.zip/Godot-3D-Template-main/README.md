# 3D-Character

An animated 3D character that can be used in the 3D-RPG project

Based on the [Kenney Character Assets](https://kenney.itch.io/kenney-character-assets) provided by kenney.nl. The model and animations were compiled in Blender and then imported into Godot.

## Implementation

Created in Blender 3.1.2 and Godot 3.4.2

## Created By

Jason Francis
